
const imageInput = document.getElementById("imageInput");
const preview = document.getElementById("preview");
const promptInput = document.getElementById("prompt");
const aiResult = document.getElementById("aiResult");
const downloadBtn = document.getElementById("downloadBtn");

imageInput.addEventListener("change", () => {
  const file = imageInput.files[0];
  if (file) {
    const reader = new FileReader();
    reader.onload = e => {
      preview.src = e.target.result;
      preview.hidden = false;
    };
    reader.readAsDataURL(file);
  }
});

async function generateAd() {
  const prompt = promptInput.value.trim();
  if (!prompt) {
    alert("Please enter a prompt!");
    return;
  }

  const url = `https://lexica.art/api/v1/search?q=${encodeURIComponent(prompt)}`;
  try {
    const res = await fetch(url);
    const data = await res.json();

    if (data.images && data.images.length > 0) {
      aiResult.src = data.images[0].srcSmall;
      aiResult.hidden = false;
      downloadBtn.hidden = false;
    } else {
      alert("No image found for this prompt.");
    }
  } catch (err) {
    alert("Error generating image.");
    console.error(err);
  }
}

function downloadAIAd() {
  const link = document.createElement("a");
  link.href = aiResult.src;
  link.download = "AdForge_AI_Ad.png";
  link.click();
}
